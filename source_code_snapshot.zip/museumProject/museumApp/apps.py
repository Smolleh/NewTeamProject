from django.apps import AppConfig


class musemAppConfig(AppConfig):
    name = 'museumApp'
