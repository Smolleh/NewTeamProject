// creating a new lesson learned
document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById('create-lessons-form')

form.addEventListener("submit", function(event) {
    event.preventDefault();

    const data = { // posting details to db
        practicalRecommendations: document.getElementById('practicalRecommendations').value,
        futureWarnings:  document.getElementById('futureWarnings').value,
    };

    fetch(`/api/exhibits/${exhibitId}/lessons-learned/new`, { // posting to api endpoint
        method: "POST",
        headers: { 
            "Content-Type": "application/json",
            "X-CSRFToken": getCSRFToken()

        },
        body: JSON.stringify(data)
    })

    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to create ");
        }
        return response.json();
    })
    .then(data => { 
        document.getElementById('message').innerText = "Creation saved";
    })
    .catch(error => {
        console.error("Error:", error);
        document.getElementById('message').innerText = "Error occured, Creation not saved.";
    });


});



});

function getCSRFToken()  {
    return document.cookie
        .split('; ')
        .find(row => row.startsWith('csrftoken='))
        ?.split('=')[1];
}